//
// Placeholder.swift
//
// Copyright © 2017 Adrian Kashivskyy.
//

public enum SwiftCheckDemoPlaceholder {}
