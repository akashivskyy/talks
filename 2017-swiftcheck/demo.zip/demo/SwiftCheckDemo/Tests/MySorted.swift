//
// MySorted.swift
//
// Never gonna let you down.
//

import SwiftCheck
import XCTest

extension Array where Element == Int {

    func counts() -> [Element: Int] {
        return reduce(into: [:], { $0[$1, default: 0] += 1 })
    }

    func elementsAreInAscendingOrder() -> Bool {
        return zip(self, dropFirst()).reduce(true) { $0 && $1.0 <= $1.1 }
    }

    func mySorted() -> [Element] {
        return sorted()
//        return dropLast().sorted()
//        return map(abs).sorted()
//        return sorted { abs($0) < abs($1) }
    }

}

internal class MySortedExample: XCTestCase {

    func testMySorted() {

        property("contains same elements as original")
        <- forAll { (a: ArrayOf<Int>) in
            a.getArray.mySorted().counts() == a.getArray.counts()
        }

        property("elements are in ascending order")
        <- forAll { (a: ArrayOf<Int>) in
            a.getArray.mySorted().elementsAreInAscendingOrder()
        }

    }

}
