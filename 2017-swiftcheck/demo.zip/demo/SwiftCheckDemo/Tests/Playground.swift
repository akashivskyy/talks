//
// Playground.swift
//
// Never gonna give you up.
//

import SwiftCheck
import XCTest

internal class PlaygroundExample: XCTestCase {

    func testAnything() {

        

    }

}











//        guard person.eligibleForRollercoaster, enlisted.count < 20 else { return false }
//        enlisted.append(person)
//        return true

//extension Person: Arbitrary {
//
//    static var arbitrary: Gen<Person> {
//        return Gen.compose { c in
//            Person(
//                age: c.generate(using: Gen<Int>.choose((1, 100))),
//                height: c.generate(using: Gen<Int>.choose((1, 300)))
//            )
//        }
//    }
//
//}
