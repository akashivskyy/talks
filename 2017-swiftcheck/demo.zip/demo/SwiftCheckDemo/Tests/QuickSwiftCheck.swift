//
// QuickSwiftCheck.swift
//
// Never gonna say goodbye.
//

import Nimble
import Quick
import QuickSwiftCheck
import SwiftCheck

internal class QuickSwiftCheckExample: QuickSpec { override func spec() {

//    property("contains same elements as original")
//    <- forAll { (a: ArrayOf<Int>) in
//        a.getArray.mySorted().counts() == a.getArray.counts()
//    }

    sc_it("contains same elements as original") {
        forAll { (a: ArrayOf<Int>) in
            expect(a.getArray.mySorted().counts()).sc_toNot(equal(a.getArray.counts()))
        }
    }

}}
