//
// Composition.swift
//
// Never gonna run around and desert you.
//

import SwiftCheck
import XCTest

internal class CompositionExample: XCTestCase {

    func testPure() {

        let onlyFive = Gen.pure(5)

        property("produces only 5") <- forAll(onlyFive) { x in
            x == 5
        }

    }

    func testFromElementsIn() {

        let lessThanFive = Gen.fromElements(in: 0...5)

        property("produces only values from 0 through 5") <- forAll(lessThanFive) { x in
            x >= 0 && x <= 5
        }

    }

    func testGenerate() {

        let customGen = Gen.fromElements(of: ["foo", "bar"])

        print(customGen.generate)
        print(customGen.generate)
        print(customGen.generate)
        print(customGen.generate)

    }

    func testSuchThat() {

        let nonZero = Int.arbitrary.suchThat { $0 != 0 }

        property("never produces 0") <- forAll(nonZero) { x in
            x != 0
        }

    }

    func testFrequency() {

        let customGen = Gen<Int?>.frequency([
            (1, Gen.pure(nil)),
            (3, Int.arbitrary.map(Optional.some))
        ])

        let results = (0..<100).map { _ in customGen.generate }.map { $0 == nil ? "none" : "some" }
        let counts = results.reduce(into: [:]) { $0[$1, default: 0] += 1 }

        print(counts)

    }

    func testEmail() {

        func glue(_ parts : [Gen<String>]) -> Gen<String> {
            return sequence(parts).map { $0.reduce("", +) }
        }

        let lowercaseChars = Gen<Character>.fromElements(in: "a"..."z")
        let uppercaseChars = Gen<Character>.fromElements(in: "A"..."Z")
        let numericChars = Gen<Character>.fromElements(in: "0"..."9")
        let specialChars = Gen<Character>.fromElements(of: ["!", "#", "$", "%", "&", "'", "*", "+", "-", "/", "=", "?", "^", "_", "`", "{", "|", "}", "~", "."])

        let localNameChars = Gen<Character>.one(of: [
            lowercaseChars,
            uppercaseChars,
            numericChars,
            specialChars,
        ])

        let localName = localNameChars
            .proliferateNonEmpty
            .suchThat { $0.dropLast().last != "." }
            .map { String($0) }

        let hostName = Gen<Character>
            .one(of: [
                lowercaseChars,
                numericChars,
                Gen.pure("-"),
            ])
            .proliferateNonEmpty
            .map { String($0) }

        let domainName = lowercaseChars
            .proliferateNonEmpty
            .suchThat { $0.count > 1 }
            .map { String($0) }

        let emailGen = glue([
            localName,
            Gen.pure("@"),
            hostName,
            Gen.pure("."),
            domainName
        ])

        print(emailGen.generate)
        print(emailGen.generate)
        print(emailGen.generate)
        print(emailGen.generate)
        print(emailGen.generate)

    }

}
