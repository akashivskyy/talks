//
// Arbitrary.swift
//
// Never gonna make you cry.
//

import Foundation
import SwiftCheck
import XCTest

struct Person: Equatable {

    let age: Int
    let height: Int

    let uuid = UUID()

    var eligibleForRollercoaster: Bool {
        return age > 12 && height > 140
    }

    static func == (_ lhs: Person, _ rhs: Person) -> Bool {
        return lhs.uuid == rhs.uuid
    }

}

class Rollercoaster {

    var enlisted: [Person] = []

    func enlist(person: Person) -> Bool {
        guard person.eligibleForRollercoaster, enlisted.count < 20 else { return false }
        enlisted.append(person)
        return true

//        guard person.eligibleForRollercoaster, enlisted.count <= 20 else {
//            return false
//        }
//        enlisted.append(person)
//        return true
    }

}

extension Person: Arbitrary {

    static var arbitrary: Gen<Person> {
        return Gen.compose { c in
            Person(
                age: c.generate(using: Int.arbitrary.suchThat { $0 < 100 }),
                height: c.generate(using: Gen<Int>.choose((0, 300)))
            )
        }
    }
}

internal class ArbitraryExample: XCTestCase {

    func testRollercoasterEnlists() {

        let r = Rollercoaster()

        property("rollercoarster should enlist all people")
        <- forAll { (p: Person) in
            p.eligibleForRollercoaster ==> r.enlist(person: p) == true
        }

    }

}
