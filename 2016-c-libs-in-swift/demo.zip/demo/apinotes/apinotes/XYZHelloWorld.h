//
// XYZHelloWorld.h
//
// Copyright © 2016 Adrian Kashivskyy. All rights reserved.
//

#ifndef XYZ_HELLO_WORLD_H
#define XYZ_HELLO_WORLD_H

#include <stdio.h>

/// Describes a "Hello, world!" instance.
typedef struct {
	const char *subject;
} XYZHelloWorld;

typedef XYZHelloWorld * XYZHelloWorldRef;

extern XYZHelloWorldRef XYZHelloWorldCreate(const char *subject);

extern void XYZHelloWorldPrint(XYZHelloWorldRef x);

#endif /* XYZ_HELLO_WORLD_H */
