//
//  XYZHelloWorld.c
//  apinotes
//
//  Created by Adrian Kashivskyy on 17.10.2016.
//  Copyright © 2016 Adrian Kashivskyy. All rights reserved.
//

#include "XYZHelloWorld.h"
