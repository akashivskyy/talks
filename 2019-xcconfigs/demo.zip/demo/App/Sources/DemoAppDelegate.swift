//
// DemoAppDelegate.swift
// Copyright © 2019 Adrian Kashivskyy. All rights reserved.
//

import UIKit
import Framework

@UIApplicationMain fileprivate class DemoAppDelegate: UIResponder, UIApplicationDelegate {

    private lazy var window: UIWindow? = {
        let window = UIWindow(frame: UIScreen.main.bounds)
        window.rootViewController = UIViewController()
        return window
    }()

    private func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        return true
    }

}

internal struct DemoAppStruct {

    internal let value: Double

    static func compute(_ lhs: DemoAppStruct, _ rhs: DemoFrameworkStruct) -> Double {
        return pow(lhs.value + rhs.value, 2)
    }

}
