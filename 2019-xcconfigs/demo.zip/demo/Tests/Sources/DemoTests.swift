//
// DemoTests.swift
// Copyright © 2019 Adrian Kashivskyy. All rights reserved.
//

@testable import App
import Framework
import XCTest

class DemoTests: XCTestCase {

    func testExample() {

        let x = DemoAppStruct(value: 2)
        let y = DemoFrameworkStruct(value: 4)

        let result = DemoAppStruct.compute(x, y)
        XCTAssertEqual(result, 36)
        
    }

}
