//
//  Framework.h
//  Framework
//
//  Created by Adrian Kashivskyy on 15/02/2019.
//  Copyright © 2019 Adrian Kashivskyy. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Framework.
FOUNDATION_EXPORT double FrameworkVersionNumber;

//! Project version string for Framework.
FOUNDATION_EXPORT const unsigned char FrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Framework/PublicHeader.h>


