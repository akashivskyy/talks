//
// DemoFrameworkStruct.swift
// Copyright © 2019 Adrian Kashivskyy. All rights reserved.
//

import Foundation

public struct DemoFrameworkStruct {

    public let value: Double

    public init(value: Double) {
        self.value = value
    }

}
